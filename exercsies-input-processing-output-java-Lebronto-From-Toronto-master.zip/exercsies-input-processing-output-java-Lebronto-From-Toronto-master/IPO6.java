class IPO6{

  public static void main(String[] args){

    int num1;
    int num2;
    int num3;
    int num4;
    int num5;
    
    
    System.out.println("165 + 182");
    num1 = In.getInt();
    System.out.println(165+182);
    System.out.println("197 - 43?");
    num2 = In.getInt();
    System.out.println(197-43);
    System.out.println("38 x 4?");
    num3 = In.getInt();
    System.out.println(38*4);
    System.out.println("81 / 9?");
    num4 = In.getInt();
    System.out.println(81 / 9);
    System.out.println("2 ^ 3?");
    num5 = In.getInt();
    System.out.println(Math.pow(2,3));
    
   
    
  }
  
}