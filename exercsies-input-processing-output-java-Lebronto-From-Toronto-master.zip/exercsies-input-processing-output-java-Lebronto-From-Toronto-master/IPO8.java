class IPO8{
  public static void main(String[] args){
    double radius;
    double circumference;
    double area; 
    System.out.println("Give me the radius of your circle.");
    radius= In.getDouble();
    circumference = 2*Math.PI*radius;
      System.out.println(circumference + " is the circumference");
    area = Math.PI * Math.pow(radius,2);
    System.out.println(area + " is the area of the circle");
  }
}