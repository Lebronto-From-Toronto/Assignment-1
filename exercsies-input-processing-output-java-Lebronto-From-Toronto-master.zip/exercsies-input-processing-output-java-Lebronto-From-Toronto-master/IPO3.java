class IPO3{

  public static void main(String[] args){

    int num1;
    int num2;
    int num3;
    int average;
    
    System.out.println("Mark 1?");
    num1 = In.getInt();
    System.out.println("Mark 2?");
    num2 = In.getInt();
    System.out.println("Mark 3?");
    num3 = In.getInt();
    average = (num1 + num2 + num3) / 3;
    System.out.println("Average = "+ average);
    
  }
  
}