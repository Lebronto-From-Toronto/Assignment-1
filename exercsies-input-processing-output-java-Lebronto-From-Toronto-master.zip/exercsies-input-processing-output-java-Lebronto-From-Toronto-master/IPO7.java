class IPO7{

  public static void main(String[] args){

    int num1;
    int num2;
    int a25;
    int born;
    int a50;
    int a75;

    
    System.out.println("Age?");
    num1 = In.getInt();
    System.out.println("Current Year?");
    num2 = In.getInt();
    born = num2 - num1;
    System.out.println("You were born in "+ born);
    a25 = (25-num1) + num2;
    System.out.println("You will be 25 in "+ a25);
    a50 = (50-num1) + num2;
    System.out.println("You will be 50 in "+ a50);
    a75 = (75-num1) + num2;
    System.out.println("You will be 75 in "+ a75);
    
    
  }
  
}