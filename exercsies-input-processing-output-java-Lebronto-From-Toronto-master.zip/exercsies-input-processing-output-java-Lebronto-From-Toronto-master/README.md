# Exercises---Input-Processing-Output---Java
Review Exercises for IPO in Java


1. Write a program that asks the user for three numbers and then outputs the sum (total) of the three numbers.  Are brackets required in the calculation?

2. Write a program that asks the user for three decimal numbers and then outputs the average of the three numbers.  Warning: Use brackets for order of operations! 

3. Write a program that asks the user to input marks for 4 courses, and the displays the average mark.  Warning: Use brackets for order of operations!

4. Using the available help or online resources for your programming language, investigate how to do #2 and #3 with your answer rounded to one decimal place. 

5. Have the user enter two integers between 1 and 9. Do the basic math operations using these numbers and display the answer (add, subtract, multiply, divide, exponent).  For example, if the user entered the numbers 2 and 3, you would output the results of 2+3, 2-3, 2*3, 2/3 and 2^3 (2 to the exponent 3).

6. Ask 5 simple math problems. After the user enters their answer, display the problem and the correct answer. The correct answer should be calculated by your program.  
Extend: Research random numbers for a way to make your program much more interesting. [Turing Code]

7. Ask the user their name, age, and the current year. Greet the user and tell them the year they were born.
Extend: Calculate and tell them the year they will be 25, 50, and 75.

8. Write a program that will ask the user for the **radius** of a circle.  The program will then calculate the **circumference** and **area** of the circle and output the results clearly.  Use a variable for words marked in **bold**.

9. Write a program that will ask the user for the **length** and **width** of a rectangle.  The program will then calculate the **perimeter** and **area** and output the results clearly.  Use variables for the words marked in **bold**.
