class IPO4{
  public static void main(String[] args){
    double number;
    double rounded;
      
    System.out.println("Give me a number XD");
    number= In.getDouble();
    
    rounded = Math.round(number *10.0)/10.0;
    System.out.println("Your rounded answer is "+rounded);
  }
}